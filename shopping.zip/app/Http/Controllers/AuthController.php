<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\SmsService;
use App\Support\PhoneNumber;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;
use Carbon\Carbon;

class AuthController extends Controller
{
    protected SmsService $smsService;
    protected bool $otpEnabled;

    public function __construct(SmsService $smsService)
    {
        $this->smsService = $smsService;
        $this->otpEnabled = (bool) config('services.otp.enabled', true);
    }

    // ---------------------------------------------------------
    // REGISTER: Create User + Send OTP (No Token Yet)
    // ---------------------------------------------------------
    public function register(Request $request)
    {
        // 1. Validate Input
        $validated = $request->validate([
            'name'     => 'required|string|max:255',
            'email'    => 'required|email|unique:users,email',
            'password' => 'required|min:6|confirmed',
            'phone'    => 'required|string|max:20',
        ]);

        // 2. NORMALIZE PHONE TO E.164
        $normalizedPhone = PhoneNumber::normalize($validated['phone']);

        if (!$normalizedPhone) {
            throw ValidationException::withMessages([
                'phone' => ['صيغة رقم الهاتف غير صحيحة. يرجى إدخاله بصيغة: 09XXXXXXXX أو +9639XXXXXXXX'],
            ]);
        }

        // 3. Check Uniqueness on Normalized Phone
        if (User::where('phone', $normalizedPhone)->exists()) {
            throw ValidationException::withMessages([
                'phone' => ['رقم الهاتف مسجل مسبقاً'],
            ]);
        }

        // ===========================================================
        // OTP DISABLED: تفعيل فوري بدون SMS (مؤقت لحين تفعيل باقة Rasel)
        // ===========================================================
        if (!$this->otpEnabled) {
            $user = User::create([
                'name'              => $validated['name'],
                'email'             => $validated['email'],
                'password'          => bcrypt($validated['password']),
                'phone'             => $normalizedPhone,
                'role'              => 'user',
                'phone_verified_at' => Carbon::now(),
            ]);

            return DB::transaction(function () use ($user) {
                $user->profile()->firstOrCreate([], [
                    'name'    => $user->name,
                    'email'   => $user->email,
                    'phone'   => $user->phone,
                    'address' => null,
                ]);

                $user->carts()->firstOrCreate(['user_id' => $user->id]);

                $token = $user->createToken('api_token')->plainTextToken;

                Log::channel('sms')->info('AuthController: User auto-verified (OTP disabled)', [
                    'user_id' => $user->id,
                ]);

                return response()->json([
                    'message' => 'تم إنشاء الحساب بنجاح',
                    'token'   => $token,
                    'user'    => $user->fresh()->load('profile'),
                    'role'    => 'user',
                ], 201);
            });
        }

        // ===========================================================
        // OTP ENABLED: التدفق الأصلي (بدون أي تعديل)
        // ===========================================================

        // 4. Generate OTP
        $otpCode = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);

        // 5. Create User (Store E.164 in DB)
        $user = User::create([
            'name'           => $validated['name'],
            'email'          => $validated['email'],
            'password'       => bcrypt($validated['password']),
            'phone'          => $normalizedPhone,
            'role'           => 'user',
            'otp_code'       => $otpCode,
            'otp_expires_at' => Carbon::now()->addMinutes(10),
        ]);

        // 6. Send SMS
        $sent = $this->smsService->sendOtp($user->phone, $otpCode);

        $phoneForFrontend = PhoneNumber::getNationalNumber($user->phone);

        if (!$sent) {
            Log::channel('sms')->warning('AuthController: Registration succeeded but SMS failed', [
                'user_id' => $user->id,
                'phone'   => $user->phone,
            ]);

            return response()->json([
                'message' => 'تم إنشاء الحساب، لكن حدث خطأ مؤقت في إرسال رمز التحقق. يرجى الضغط على "إعادة الإرسال" في صفحة التفعيل.',
                'phone'   => $phoneForFrontend,
            ], 201);
        }

        return response()->json([
            'message' => 'تم إرسال رمز التحقق',
            'phone'   => $phoneForFrontend,
        ], 201);
    }

    // ---------------------------------------------------------
    // VERIFY OTP: Activate Account + Issue Token
    // ---------------------------------------------------------
    public function verifyOtp(Request $request)
    {
        if (!$this->otpEnabled) {
            return response()->json(['message' => 'ميزة التحقق عبر الرمز معطلة حالياً'], 400);
        }

        $validated = $request->validate([
            'phone'    => 'required|string',
            'otp_code' => 'required|string|size:6',
        ]);

        $normalizedPhone = PhoneNumber::normalize($validated['phone']);

        if (!$normalizedPhone) {
            return response()->json(['message' => 'رقم هاتف غير صالح'], 400);
        }

        $user = User::where('phone', $normalizedPhone)->first();

        if (!$user) {
            return response()->json(['message' => 'رقم الهاتف غير مسجل'], 404);
        }

        if ($user->phone_verified_at) {
            return response()->json(['message' => 'الحساب مفعل مسبقاً', 'redirect' => 'login'], 409);
        }

        if (!$user->otp_code || !$user->otp_expires_at) {
            return response()->json(['message' => 'لا يوجد رمز تحقق فعال، يرجى طلب رمز جديد'], 400);
        }

        if (Carbon::now()->greaterThan($user->otp_expires_at)) {
            return response()->json(['message' => 'انتهت صلاحية رمز التحقق، يرجى طلب رمز جديد'], 410);
        }

        if (!hash_equals((string) $user->otp_code, (string) $validated['otp_code'])) {
            return response()->json(['message' => 'رمز التحقق غير صحيح'], 422);
        }

        return DB::transaction(function () use ($user) {
            $user->phone_verified_at = Carbon::now();
            $user->otp_code = null;
            $user->otp_expires_at = null;
            $user->save();

            $user->profile()->firstOrCreate([], [
                'name'    => $user->name,
                'email'   => $user->email,
                'phone'   => $user->phone,
                'address' => null,
            ]);

            $user->carts()->firstOrCreate(['user_id' => $user->id]);

            $token = $user->createToken('api_token')->plainTextToken;

            return response()->json([
                'message' => 'تم تفعيل الحساب بنجاح',
                'token'   => $token,
                'user'    => $user->fresh()->load('profile'),
                'role'    => 'user',
            ], 200);
        });
    }

    // ---------------------------------------------------------
    // RESEND OTP
    // ---------------------------------------------------------
    public function resendOtp(Request $request)
    {
        if (!$this->otpEnabled) {
            return response()->json(['message' => 'ميزة التحقق عبر الرمز معطلة حالياً'], 400);
        }

        $validated = $request->validate(['phone' => 'required|string']);

        $normalizedPhone = PhoneNumber::normalize($validated['phone']);

        if (!$normalizedPhone) {
            return response()->json(['message' => 'رقم هاتف غير صالح'], 400);
        }

        $user = User::where('phone', $normalizedPhone)->first();

        if (!$user) {
            return response()->json(['message' => 'رقم الهاتف غير مسجل'], 404);
        }

        if ($user->phone_verified_at) {
            return response()->json(['message' => 'الحساب مفعل مسبقاً'], 409);
        }

        $otpCode = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
        $user->otp_code = $otpCode;
        $user->otp_expires_at = Carbon::now()->addMinutes(10);
        $user->save();

        $sent = $this->smsService->sendOtp($user->phone, $otpCode);

        if (!$sent) {
            return response()->json([
                'message' => 'تعذر إرسال رمز التحقق حالياً، يرجى المحاولة لاحقاً',
            ], 502);
        }

        return response()->json([
            'message' => 'تم إعادة إرسال رمز التحقق',
            'phone'   => PhoneNumber::getNationalNumber($user->phone),
        ], 200);
    }

    // ---------------------------------------------------------
    // LOGIN
    // Accepts a single "login" field that can be either an email
    // or a phone number (any format PhoneNumber::normalize() accepts).
    // ---------------------------------------------------------
    public function login(Request $request)
    {
        $credentials = $request->validate([
            'login'    => 'required|string',
            'password' => 'required',
        ]);

        $loginInput = trim($credentials['login']);
        $genericError = ['message' => 'البيانات غير صحيحة'];

        // Decide whether the input is an email or a phone number,
        // then look up the user on the matching column only.
        if (filter_var($loginInput, FILTER_VALIDATE_EMAIL)) {
            $user = User::where('email', $loginInput)->first();
        } else {
            $normalizedPhone = PhoneNumber::normalize($loginInput);

            if (!$normalizedPhone) {
                // Not a valid email and not a valid phone — same generic
                // message as a wrong password, so we don't leak which
                // field was the problem.
                return response()->json($genericError, 401);
            }

            $user = User::where('phone', $normalizedPhone)->first();
        }

        if (!$user || !Hash::check($credentials['password'], $user->password)) {
            return response()->json($genericError, 401);
        }

        if ($user->role !== 'admin' && !$user->phone_verified_at) {
            return response()->json([
                'message'                => 'يرجى تفعيل رقم هاتفك أولاً',
                'phone'                  => PhoneNumber::getNationalNumber($user->phone),
                'requires_verification'  => true,
            ], 403);
        }

        $user->tokens()->delete();

        $token = $user->createToken('api_token')->plainTextToken;

        return response()->json([
            'message' => 'تم تسجيل الدخول بنجاح',
            'token'   => $token,
            'user'    => $user->load('profile'),
        ]);
    }

    // ---------------------------------------------------------
    // LOGOUT
    // ---------------------------------------------------------
    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();
        return response()->json(['message' => 'تم تسجيل الخروج بنجاح']);
    }
}
