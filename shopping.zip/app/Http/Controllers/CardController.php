<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreCardRequest;
use App\Http\Requests\UpdateCardRequest;
use App\Models\Cart;
use Illuminate\Support\Facades\Auth;



class CardController extends Controller
{

    public function index($cartId)
    {
        $cart = Cart::with('cartItems.product')->findOrFail($cartId);
        $this->authorize('view', $cart);

        return response()->json($cart);
    }


    public function show(Cart $cart)
    {
        $this->authorize('view', $cart);

        return response()->json($cart);
    }


    public function store(StoreCardRequest $request)
    {
        $this->authorize('create', Cart::class);

        $cart = Cart::create($request->validated());

        return response()->json([
            'message' => 'Card created successfully',
            'data' => $cart
        ], 201);
    }

    public function destroy(Cart $cart)
    {
        $this->authorize('delete', $cart);

        $cart->delete();

        return response()->json([
            'message' => 'Card deleted successfully'
        ]);
    }



    public function update(UpdateCardRequest $request, Cart $cart)
    {
        $this->authorize('update', $cart);

        $cart->update($request->validated());

        return response()->json([
            'message' => 'Card updated successfully',
            'data' => $cart,
        ]);
    }


    public function myCart()
    {
        $cart = Cart::where('user_id', Auth::id())
            ->with('cartItem.product')
            ->firstOrFail();

        return response()->json($cart);
    }

    public function myCartTotal()
    {
        $cart = Cart::where('user_id', Auth::id())
            ->with('cartItem')
            ->firstOrFail();

        $total = $cart->cartItem->sum(
            fn($item) =>
            $item->quantity * $item->unit_price
        );

        return response()->json([
            'total_price' => $total
        ]);
    }

    public function clearMyCart()
    {
        $cart = Cart::where('user_id', Auth::id())->firstOrFail();
        $cart->cartItem()->delete();

        return response()->json([
            'message' => 'Cart cleared successfully'
        ]);
    }
}
