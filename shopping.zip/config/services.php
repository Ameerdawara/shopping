<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'postmark' => [
        'key' => env('POSTMARK_API_KEY'),
    ],

    'resend' => [
        'key' => env('RESEND_API_KEY'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],

   'rasel' => [
    'url'     => env('RASEL_API_URL', 'https://raselsms.com/api/v2/messages/send'),
    'api_key' => env('RASEL_API_KEY'),
],

    // مفتاح تشغيل/إيقاف نظام OTP بالكامل — عطّله مؤقتاً لحين تفعيل باقة Rasel المدفوعة
    // لإعادة التفعيل لاحقاً: غيّر القيمة بـ .env فقط (OTP_ENABLED=true) — بدون لمس أي كود آخر
    'otp' => [
        'enabled' => env('OTP_ENABLED', true),
    ],

];
